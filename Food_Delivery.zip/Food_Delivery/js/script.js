const toggleBtn = document.querySelector('.toggleMenu');
const menu = document.querySelector('.menu ul');

toggleBtn.addEventListener('click',function(){
    menu.classList.toggle('show');
});


const darkmodetoggle = document.querySelector('.dark-mode-toggle');
const body = document.querySelector('body');

darkmodetoggle.addEventListener('click',()=>{
    body.classList.toggle('dark-mode');
    updateDarkmodeicon();});

function updateDarkmodeicon(){
    const darkmodeicon = darkmodetoggle.querySelector('i');

    if(body.classList.contains('dark-mode')){
        darkmodeicon.classList.remove('fa-moon');
        darkmodeicon.classList.add('fa-sun');
    }
    else{
        darkmodeicon.classList.add('fa-moon');
        darkmodeicon.classList.remove('fa-sun');
    }
    
}   
//.. add to cart ..

document.addEventListener('DOMContentLoaded',()=>{
    const carticons = document.querySelectorAll('.section3 .slide .images a');
    const cartcount = document.querySelector('.icons .sp');
    const totalamount = document.querySelector('.icons .total .totalAmount');
    const orderbutton = document.querySelector('.icons .orderBtn');

    carticons.forEach(icon=>{
        icon.addEventListener('click',(event)=>{
            event.preventDefault();
            let count = parseInt(cartcount.textContent);
            count++;
            cartcount.textContent = count;

            // update total amount
            const price = parseFloat(icon.closest('.images').dataset.price);
            let total = parseFloat(totalamount.textContent);
            total+=price;
            totalamount.textContent = total.toFixed(2);
        })
    })

    orderbutton.addEventListener('click',()=>{
        //reset cart count & total amount
        cartcount.textContent='0';
        totalamount.textContent='0.00';

        alert("Thank you for your order ! Have a Good Day")
    });
})

document.addEventListener('DOMContentLoaded',function(){
    const star = document.querySelectorAll('.rating i');
    const modal = document.getElementById('thankyoumodal');
    const messageElement = document.getElementById('thankyoumessage');
    const closemodal = document.querySelectorAll('close');

    star.forEach(star =>{
        star.addEventListener('click',function(){
      const rating = this.getAttribute('data-rating');
      const parent = this.parentNode;
      parent.setAttribute('data-rating',rating);
      updatestars(parent,rating);
      displaythankyou(rating);
        });
    });

    function updatestars(parent,rating){
        const stars = parent.querySelectorAll('i');
        stars.forEach(star =>{
            if(star.getAttribute('data-rating')<=rating){
                star.classList.remove('fa-regular');
                star.classList.add('fa-solid');
            }
            else{
                star.classList.add('fa-regular');
                star.classList.remove('fa-solid');
            }
        })
    }
});
